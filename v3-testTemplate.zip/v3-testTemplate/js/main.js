/**
 * File Name: Main.js
 * Live Demo: <> 
 * Source Code: http://makingbrowsergames.com/book/
 * Description: File for controlling and displaying game scenes; 
 * 		managing global variables throughout game state.
 * Author: Stephen Gose
 * Version: 0.0.0.xx
 * Phaser Version: 3.x.x
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //TODO ] to tailor this file for your own use; 
 *	 doing so will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 */
"use strict";
/**	game set-up	**/
//Beginning of Static databases
//TODO 
// NOTE: the following data structures are for development only.
//	The optimum usage is a local or remote database using PouchDB or SQLite.
//	Stay away from IndexDB since it is deprecated.
console.log("%c      Starting my awesome MMoG game Prototype!     \n     Phaser Match 3 Game Prototyping Starter Kit   \n        Copyright \u00A9 1974-2018,  Stephen Gose.      \n  | http://shop.pbmcube.net/|                      \n  | \u2665\u2665\u2665\u2665\u2665 -> $120 License included in book!        \n  | Book available at: http://leanpub.com/LoRD |   ",
	"color:white; background:blue");
var boardGroup;
var selectedTile;
var game = {};	//now required for Phaser3
// 
// =========================================================
//TODO Creating Game namespace called GAMEAPP; re-factor 
//   GAMEAPP with your project's name
window.GAMEAPP =  {
	//US Copr. or Copyright; UTF8 "circled c" is \u00A9 equivalent to &copy;
	Copr: "Copyright © \u00A9 1974-2016, Stephen Gose. All rights reserved.\n",
	// reference to the Phaser.Game instance
	
	//game: {},
		
	// If there's music in your game, and it needs to play through-out a 
	//	  few State swaps, then you could reference it below. 
	//music: null,
	
	//Toggle background music theme on or off; starts in "on/true" state 
	//musicToggle: true,
	
	//Your game can check MYGAMEAPP.orientated in the game loops 
	//	  to know if it should pause or not.
	//orientated: false,
	
	/**
	//Grid Tile-Map configurations
	//TODO Remote this static database onto database server; otherwise upgrade to PouchDB or SQLite
	//Tile-maps are the visual express separate from the Movement Tables metadata.
	tileSize: 64,	//twice the size of an avatar icon
	numRows: 3,		//adjustable for your game
	numCols: 3,		//adjustable for your game
	tileSpacing: 2,	//adjustable for your game
	tilesArray: [], //one way; thousand more to choose
	*/
	//Canvas dimensions: world and viewportHeight
	//TODO adjust for your game deployment
	viewportWidth: 800,	//Golden ration game view
	viewportHeight: 500,
	worldWidth: 800,	//Golden ration world view
	worldHeight: 500,
	
	// =========================================================
	//TODO re-factor and adjust for your game's deployment
	//	Trash Global Variables (alphabetical)
	//	Here we have some global level vars that persist regardless of State. 
	// =========================================================
	canPick: true,	
	comboCntr: 0,	
	//combination toggle sentinel for combinations earned
	comboT: false,
	//	
	destroySpeed: 200,	
	fallSpeed: 500,	
	fastFall: true,	
	fieldSize: 7,
	//	
	gameArray: [],	
	removeMap: [],
	//Scoring	
	score3: 0,	//3 in a row matches
	score4: 0,	//4 in a row matches
	score5: 0,	//5 in a row matches
	scoreC: 0,	//Combinations scored
	swapSpeed: 200,	
	//
	tileSize: 40,	
	tileTypes: 5,	
	
	//HUD styling
	styleHUD: { font: "16px Arial", fill: "#ff9900", align: "left" },
	
	// here we will store all game phase/states
	//  state object filled as js files load.
	state: {},
	
	// =========================================================
	// -------------------------------------------
	// Main game Handler methods
	// -------------------------------------------
	//TODO:
	//	re-factor and adjust for your game deployment
	//	remove console debug information on public deployment
	// =========================================================
	main: function(){
		/**
		 
		 //v2.6.2 or CE game launch
		this.game = new Phaser.Game(window.GAMEAPP.viewportWidth, window.GAMEAPP.viewportHeight, Phaser.AUTO, document.body, window.GAMEAPP.state.boot);
		*/
		//NEW in Phaser v3.x.x game launch
		//   Phaser docs suggests a separate config = {...}; I don't.
		//See Phaser Game Prototyping for all the new parameters in
		//   Phaser3 configuration object.
		//   available from https://leanpub.com/LoRD or Amazon
		//Now override the root game object and link into Phaser.Game
		game = new Phaser.Game({
					type: Phaser.AUTO,
					parent: document.body,
					width: window.GAMEAPP.viewportWidth,
					height: window.GAMEAPP.viewportHeight,
					scene:[window.GAMEAPP.state]
			
		});	
		
		// add all game states
		for(var stateName in window.GAMEAPP.state){
			console.log("Crnt State: "+stateName);
			game.scene.add(stateName, window.GAMEAPP.state[stateName],true);
			
		}
	
		//using v3? use this manual start method below.
		console.log("Leaving GAMEAPP.main -> boot");	//debug
		game.scene.start('boot');
		
	},
	// =========================================================
	// -------------------------------------------
	// Supporting game Function & Classes
	// -------------------------------------------
	//TODO:
	//	Change name-space from generic GAMEAPP to your project 
	//	re-factor and adjust for your game deployment
	//	remove console debug information on public deployment
	// =========================================================
}

/** DEPRECATED METHOD - NEVER EVER USE THIS!
* 	See Phaser.js Game Design Workbook for complete explanation
*	http://leanpub.com/phaserjsgamedesignworkbook
* 	window.onload = function () {
*	    let game = new Phaser.Game(0, 0, Phaser.AUTO, document.body);
*	};
*/

//preferred launch method for BOM.
window.addEventListener('DOMContentLoaded', function(){
	 
	window.GAMEAPP.main();
}, false);

/** End of file
 *  Location: /js/main.js
 */