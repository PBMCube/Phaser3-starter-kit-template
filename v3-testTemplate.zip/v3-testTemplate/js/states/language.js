/**
 * File Name: language.js
 * File URL: http://www.adventurers-of-renown.com/GAMEAPP/index.html
 * Description: File for controlling initial entry into game shell and scenes; managing global variables throughout game state.
 * Author: Stephen Gose
 * Version: 0.0.0.17
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //**TODO** ] to tailor this file for your own use 
 *   and will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 * This file is automatically loaded from state/load.js
 * to change default state - change state/load.js at line: 34
 */
"use strict";
window.GAMEAPP.state.language = {
	preload: function(){
		console.log(" %c ARxx rv_17 Game Prototype language game resources ", "color:white; background:red");
		this.load.image('langScene', 'assets/images/staticScenes/languageScene.jpg');
		//using altas for graphics; loading graphics for the main menu state now; 
		//	they should be in the cache when needed.
		//	game theme music file should be deferred to splash/language phase.
		//navigation and menu buttons; 
		//two methods to load spriteSheets: 1) classic or 2) texture atlas
		//load navigation buttons using classic method
		//using programmatic method
		//this._preloadResources();
	},
	
	create: function(){
		var CrntLang= localStorage.getItem("curLang"); 
		
		console.log("starting language selection state");
		this.game.add.image(0, 0, 'langScene');
		
		//Language buttons - top row
		var china = this.game.add.button(this.world.centerX-110, this.world.centerY-50, 'chinaBtn', this.clickLangSelected, this, 1, 0, 2,0);
		china.name = "china";
		china.onInputOver.add(this.btnOver, this);
		china.inputEnabled = true;
		china.scale.setTo(0.9,0.9);
		
		var dmark = this.game.add.button(this.world.centerX-60, this.world.centerY-50, 'dmarkBtn', this.clickLangSelected, this, 1, 0, 2,0);
		dmark.name = "denmark";
		dmark.onInputOver.add(this.btnOver, this);
		dmark.inputEnabled = true;
		dmark.scale.setTo(0.9,0.9);
		
		var english = this.game.add.button(this.world.centerX-10, this.world.centerY-50, 'englishBtn', this.clickLangSelected, this, 1, 0, 2,0);
		english.name = "english";
		english.onInputOver.add(this.btnOver, this);
		english.inputEnabled = true;
		english.scale.setTo(0.9,0.9);
		
		var french = this.game.add.button(this.world.centerX+40, this.world.centerY-50, 'frenchBtn', this.clickLangSelected, this, 1, 0, 2,0);
		french.name = "french";
		french.onInputOver.add(this.btnOver, this);
		french.inputEnabled = true;
		french.scale.setTo(0.9,0.9);
		
		var german = this.game.add.button(this.world.centerX+90, this.world.centerY-50, 'germanBtn', this.clickLangSelected, this, 1, 0, 2,0);
		german.name = "german";
		german.onInputOver.add(this.btnOver, this);
		german.inputEnabled = true;
		german.scale.setTo(0.9,0.9);
		
		var italy = this.game.add.button(this.world.centerX-160, this.world.centerY-50, 'italyBtn', this.clickLangSelected, this, 1, 0, 2,0);
		italy.name = "italy";
		italy.onInputOver.add(this.btnOver, this);
		italy.inputEnabled = true;
		italy.scale.setTo(0.9,0.9);
		
		//Language buttons - bottom row
		var nland = this.game.add.button(this.world.centerX-135, this.world.centerY+10, 'nlandBtn', this.clickLangSelected, this, 1, 0, 2,0);
		nland.name = "netherlands";
		nland.onInputOver.add(this.btnOver, this);
		nland.inputEnabled = true;
		nland.scale.setTo(0.9,0.9);
		
		var japan = this.game.add.button(this.world.centerX+65, this.world.centerY+10, 'japanBtn', this.clickLangSelected, this, 1, 0, 2,0);
		japan.name = "japan";
		japan.onInputOver.add(this.btnOver, this);
		japan.inputEnabled = true;
		japan.scale.setTo(0.9,0.9);
		
		var portugal = this.game.add.button(this.world.centerX+15, this.world.centerY+10, 'portugalBtn', this.clickLangSelected, this, 1, 0, 2,0);
		portugal.name = "portugal";
		portugal.onInputOver.add(this.btnOver, this);
		portugal.inputEnabled = true;
		portugal.scale.setTo(0.9,0.9);
		
		var spain = this.game.add.button(this.world.centerX-35, this.world.centerY+10, 'spainBtn', this.clickLangSelected, this, 1, 0, 2,0);
		spain.name = "spain";
		spain.onInputOver.add(this.btnOver, this);
		spain.inputEnabled = true;
		spain.scale.setTo(0.9,0.9);
		
		var sweden = this.game.add.button(this.world.centerX-85, this.world.centerY+10, 'swedenBtn', this.clickLangSelected, this, 1, 0, 2,0);
		sweden.name = "sweden";
		sweden.onInputOver.add(this.btnOver, this);
		sweden.inputEnabled = true;
		sweden.scale.setTo(0.9,0.9);
		
		//Goto main menu
		var buttonContinue = this.game.add.button(this.world.width, this.world.centerY+50, 'button-continue', this.clickContinue, this, 1, 0, 2,0);
		
		buttonContinue.anchor.set(1,1);
		buttonContinue.x = this.world.width+buttonContinue.width+20;
		
		this.add.tween(buttonContinue).to({x: this.world.width-20}, 500, Phaser.Easing.Exponential.Out, true);

		this._toolTip = this.game.add.text(this.world.centerX, this.world.centerY-80, GAMEAPP.InfoText, GAMEAPP.styleRA);
		this._toolTip.anchor.set(0.5,0.5);
		this._toolTip.setShadow(3, 3, 'rgba(0,0,0,0.5)', 5);
		this._toolTip.fontWeight = 'bold';
		
		this.camera.flash(0x000000, 500, false);
	},
	
	update: function(){
		
	},
	
	btnOver: function(butn){
		switch(butn.name){
			case "china":
				GAMEAPP.gameLanguage = 1;
				console.log("Chinese selected");
				this._toolTip.setText("Chinese | 中文 "); 
				break;
			
			case "denmark":
				GAMEAPP.gameLanguage = 2;
				console.log("Danish selected");
				this._toolTip.setText("Danish | Dansk sprog "); 
				break;
			
			case "english":
				GAMEAPP.gameLanguage = 0;
				console.log("English selected");
				this._toolTip.setText("Default Language: English\n Select language then click arrow to enter."); 
				break;
			
			case "french":
				GAMEAPP.gameLanguage = 3;
				console.log("French selected");
				this._toolTip.setText("French | langue française "); 
				break;

			case "german":
				GAMEAPP.gameLanguage = 4;
				console.log("German selected");
				this._toolTip.setText("German | deutsche Sprache "); 
				break;	
				
			case "italy":
				GAMEAPP.gameLanguage = 5;
				console.log("Italian selected");
				this._toolTip.setText("Italian | lingua italiana "); 
				break;
			
			case "japan":
				GAMEAPP.gameLanguage = 6;
				console.log("Japanese selected");
				this._toolTip.setText("Japanese | 日本語 "); 
				break;
			
			case "netherlands":
				GAMEAPP.gameLanguage = 7;
				console.log("Dutch selected");
				this._toolTip.setText("Dutch | Nederlandse taal "); 
				break;
			
			case "portugal":
				GAMEAPP.gameLanguage = 8;
				console.log("Portuguese selected");
				this._toolTip.setText("Portuguese | idioma portugues "); 
				break;
			
			case "spain":
				GAMEAPP.gameLanguage = 9;
				console.log("Spanish selected");
				this._toolTip.setText("Spanish | língua espanhola "); 
				break;
			
			case "sweden":
				GAMEAPP.gameLanguage = 10;
				console.log("Swedish selected");
				this._toolTip.setText("Swedish | Svenska språket "); 
				break;
			
			default:
				console.log("English selected");
				GAMEAPP.gameLanguage = 0;
				this._toolTip.setText("Default Language: English\n Select language then click arrow to enter."); 
				break;
		}
	},
	
	clickContinue: function() {
		//GAMEAPP._playAudio('click');
		this.camera.fade(0x000000, 200, false);
		localStorage.setItem("curLang", GAMEAPP.gameLanguage);
		this.time.events.add(200, function() {
			//this.game.state.start('Main');	//BBS & Flash website: TIGStart method
			this.game.state.start('story');		//ARRA Main Entrance rv_3 through rv_8
		}, this);
		
	},
	
	clickLangSelected: function() {
		GAMEAPP._assignLanguage(GAMEAPP.gameLanguage);
		localStorage.setItem("curLang", GAMEAPP.gameLanguage);
		//GAMEAPP._playAudio('click');
		this.camera.fade(0x000000, 200, false);
		this.time.events.add(200, function() {
			//this.game.state.start('Main');	//BBS & Flash website: TIGStart method
			this.game.state.start('story');		//ARRA Main Entrance rv_3 through rv_8
		}, this);
		
	},
	
	_preloadResources() {
	var pack = this.resources;
		for(var method in pack) {
			pack[method].forEach(function(args) {
				var loader = this.load[method];
				loader && loader.apply(this.load, args);
			}, this);
		}
	}
};
//
// =========================================================
/**
//internal static; JSON game resources
function getText(section, index){
	return game.cache.getJSON('langs').langs[curLang][section].texts[index];
}

function setLang(l){
	curLang = l;
}

function createLanguageFlags(){
	game.add.button(19, 373, 'flags', function(){updateLanguage("PT_BR")}, this, 0, 0, 0);
	game.add.button(56, 373, 'flags', function(){updateLanguage("EN")}, this, 1, 1, 1);
	game.add.button(93, 373, 'flags', function(){updateLanguage("ES")}, this, 2, 2, 2);
	game.add.button(130, 373, 'flags', function(){updateLanguage("GE")}, this, 3, 3, 3);
	game.add.button(19, 410, 'flags', function(){updateLanguage("RU")}, this, 4, 4, 4);
	game.add.button(56, 410, 'flags', function(){updateLanguage("JP")}, this, 5, 5, 5);
	game.add.button(93, 410, 'flags', function(){updateLanguage("IT")}, this, 6, 6, 6);
	game.add.button(130, 410, 'flags', function(){updateLanguage("FR")}, this, 7, 7, 7);
}

function updateLanguage(newLang){
	setLang(newLang);
	localStorage.setItem("curLang", curLang);
	game.state.start(game.state.current)
}
*/

/* End of file */
/* Location: ./js/state/language.js */