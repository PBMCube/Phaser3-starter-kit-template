/**
 * File Name: boot.js
 * Live Demo: <> 
 * Source Code: http://makingbrowsergames.com/book/
 * Description: File for controlling initial game shell launch; 
 *		managing global variables throughout game state.
 * Author: Stephen Gose
 * Version: 0.0.0.xx
 * Phaser Version: 3.x.x
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //TODO ] to tailor this file for your own use; 
 *	 doing so will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 */
"use strict";
window.GAMEAPP.state.boot = {
	preload: function(){
		console.log("Entering boot");	//debug
		// required assets for following states here
		this.load.image('scoreHUD', 'assets/images/scoreBar.png');
		this.load.spritesheet("tiles", 'assets/spriteSheets/arbp-m3.png', {frameWidth:40, frameHeight: 40});
	},
	create: function(){
		console.log("Entering boot -> create");	//debug	
		
		// goto load state
		console.log("Entering load");	//debug
		game.scene.start("load");
	},
	enableScaling: function(){
		var game = this.game;
		game.scale.parentIsWindow = (game.canvas.parentNode == document.body);
		game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
	}
};
/** End of file
 *  Location: /js/states/boot.js
 */