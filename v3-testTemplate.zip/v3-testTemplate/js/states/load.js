/**
 * File Name: load.js
 * Live Demo: <> 
 * Source Code: http://makingbrowsergames.com/book/
 * Description: File for controlling assets downloads; 
 *		some delegations to browser.
 * Author: Stephen Gose
 * Version: 0.0.0.xx
 * Phaser Version: 3.x.x
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //TODO ] to tailor this file for your own use; 
 *	 doing so will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 */
 
"use strict";

window.GAMEAPP.state.load = {
	preload: function(){
		console.log("Entering load");	//debug
		// we have preloaded assets required for Loading group objects
		//	from the Boot state.
		
	},
	
	create: function(){
		// loading has finished - proceed to where? demo state? languages?
		console.log("Leaving load");	//debug
		game.scene.start('language');
	}
};
/** End of file
 *  Location: /js/states/load.js
 */