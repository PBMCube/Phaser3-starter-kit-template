/**
 * File Name: demo.js
 * Live Demo: <>
 * Source Code: http://makingbrowsergames.com/starterkits/
 * Description: File for launching game demonstrations scenes; 
 *		managing global variables throughout game state.
 * Author: Stephen Gose
 * Version: 0.0.0.xx
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //**TODO** ] to tailor this file for your own use 
 *   and will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 * This file is automatically loaded from state/load.js
 * to change default state - change state/load.js at line: 10
 */
"use strict";
window.GAMEAPP.state.demo = {
	create: function(){
				
		// prevent pause on focus lost
		this.game.stage.disableVisibilityChange = true;
	}
};
/** End of file
 *  Location: /js/states/demo.js
 */