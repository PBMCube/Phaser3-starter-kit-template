/**
 * File Name: Credit.js
 * File URL: http://www.adventurers-of-renown.com/GAMEAPP/index.html
 * Description: File for controlling game credits, recognitions, 
 *		and sponsor recommendation.
 * Author: Stephen Gose
 * Version: 0.0.0.xx
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright � \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //**TODO** ] to tailor this file for your own use 
 *   and will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 * This file is automatically loaded from state/load.js
 * to change default state - change state/load.js at line: 34
 */
 
window.GAMEAPP.state.credits = {
	preload: function (){
		console.log(" %c ARxx rv_17 Credits Menu Game Prototype", "color:white; background:red");
		GAMEAPP.InfoText = "Game Credits and Information";
		//ARxx credits and acknowledgements
		this.game.add.image(0, 0, 'creditScene');
		this.load.spritesheet('button', 'assets/spriteSheets/mmog-sprites-silver.png', 129, 30);
		//using altas for graphics; loading graphics for the main menu state now; 
		//	they should be in the cache when needed.
		//	game theme music file should be deferred to splash/language phase.
		//navigation and menu buttons; 
		//two methods to load spriteSheets: 1) classic or 2) texture atlas
		//load navigation buttons using classic method
		//using programmatic method
		
	},

	create: function () {
		//return to main menu txt
		var mmtxt = this.add.text(0, 0, "Return", GAMEAPP.styleBTN);
		var tooltxt = this.game.add.text(this.world.centerX, this.world.centerY+30, "ARxxx is a xxxxxxx game by Stephen Gose Game Studios.\nSteve Gose -- is a professional eLearning specialist and\n managed a multi-national eLearning program for the US & Japan\n regions of for several global telecommunication corporations.\n\n		Currently is a Professor at UAT.edu and He owns and operates\n PBMCube - Play By Mail, eMail & Modem games,\n and TB-Cube - Training by Blackboard, Books & Browsers an online / eLearning provider).\n\nLearn more at http://www.stephen-gose.com or\n visit his linkedIn page\n https://www.linkedin.com/in/stephen-gose-phd-71ba853b/", GAMEAPP.styleHUD);
		
		text = this.game.add.text(this.world.centerX, 145, "Credits & Help", GAMEAPP.styleHUD);

		text.anchor.setTo(0.5, 0.5);
		text.setShadow(3, 3, 'rgba(0,0,0,0.5)', 5);
		text.setTextBounds(550, 138, 780, 400);
		text.fontWeight = 'bold';
		
		tooltxt.anchor.setTo(0.5, 0.5);
		tooltxt.setShadow(3, 3, 'rgba(0,0,0,0.5)', 5);
		tooltxt.fontWeight = 'bold';
			
		//Goto main menu
		var buttonContinue = this.game.add.button(this.world.width, this.world.centerY+50, 'button-continue', this.quitGame, this, 1, 0, 2,0);
		
		buttonContinue.anchor.set(1,1);
		buttonContinue.x = this.world.width+buttonContinue.width+20;
		
		this.add.tween(buttonContinue).to({x: this.world.width-20}, 500, Phaser.Easing.Exponential.Out, true);
		
	},


	update: function () {

		

	},

	quitGame: function (pointer) {

		//	Then let's go back to the main menu.
		this.state.start('story');

	}

};
