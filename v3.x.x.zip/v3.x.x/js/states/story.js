/**
 * File Name: story.js
 * File URL: http://www.adventurers-of-renown.com/GAMEAPP/index.html
 * Description: File for background story and instructions.
 * Author: Stephen Gose
 * Version: 0.0.0.xx
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //**TODO** ] to tailor this file for your own use 
 *   and will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 * This file is automatically loaded from state/load.js
 * to change default state - change state/load.js at line: 34
 */
"use strict";
// 
// =========================================================
//AR: NCC Padora story generator
var plotType = [	
    "Your story is ...",
    "Your tale begins this way ...",
    "Here's how your new Quest begins ...",
    "Here's what happened ...",
    "Once upon a time in a galaxy far far away ..."

	];
// 
// =========================================================
var authorityFigure = [
    "You are brilliant, yet infamous, rogue merchant smuggler escaping the local star system within the",  
    "You are a Space Marine warrior transferring to a new duty station in the",  
    "You are a quality assurance scientist assigned to monitor the",  
    "You are a cargo merchant travelling to the",  
    "You are an engineering student transferring to the University in the",  
    "You are a pious and powerful cleric on an inquisition mission to the",
    "You are a powerful legendary Jedi sensing something unusal in the",  
    "You are a rich consultant seeking to advise business in the",  
    "Your are a chancellor/advisor of the local lord on assignment to the",  
    "You are the head of the local adventurer's guild auditing chapters based in the", 
    "You are the local captain of the guard on escort duty to the",   
];  
var greekNames = [
	"Acantha",
	"Achilles",
	"Adonis",
	"Adrastea",
	"Adrastos",
	"Aegle",
	"Aella",
	"Agaue",
	"Aiolos",
	"Alekto",
	"Althea",
	"Cassandra",
	"Castor",
	"Chloe",
	"Damon",
	"Daphne",
	"Dardanos",
	"Epimetheus",
	"Europa",
	"Nemesis",
	"Oedipus",
	"Pegasus"

];

var greekLetters = [	
    "Alpha",  
    "Beta",  
    "Gamma",
	"Delta",
	"Epsilon",
	"Zeta",
	"Eta",
	"Theta",
	"Iota",
	"Kappa",
	"Lambda",
	"Mu",
	"Nu",
	"Xi",
	"Omicron",
	"Pi",
	"Rho",
	"Sigma",
	"Tau",
	"Upsilon",
	"Phi",
	"Chi",
	"Psi",
	"Omega",
    
];  
// 
// =========================================================
window.GAMEAPP.state.story = {
	preload: function(){
		console.log(" %c ARxx rv_17 Story & Main Menu Game Prototype", "color:white; background:red");
		//GAMEAPP.InfoText = "Main Menu Selections";
		
		//ARxx mainMenu & Story collapse into one scene
		this.load.spritesheet('button', 'assets/spriteSheets/mmog-sprites-silver.png', 129, 30);
		//GAMEAPP._assignLanguage(GAMEAPP.gameLanguage);
		//using altas for graphics; loading graphics for the main menu state now; 
		//	they should be in the cache when needed.
		//	game theme music file should be deferred to splash/language phase.
		//navigation and menu buttons; 
		//two methods to load spriteSheets: 1) classic or 2) texture atlas
		//load navigation buttons using classic method
		//using programmatic method
		//this._preloadResources();
	},
	
	create: function(){
		console.log("starting story line state");
		var style = {};
		
		if (GAMEAPP.gameLanguage == 0) {
			this.game.add.image(0, 0, 'storyScene');
			style = { font: "12px Arial", fill: "#F90", align: "center", boundsAlignH: "left", boundsAlignV: "top", wordWrap: true, wordWrapWidth: 245 };
			this.introParatxt = this.add.text(1000,0, GAMEAPP.introPara, style);
			this.introParatxt.setShadow(3, 3, 'rgba(0,0,0,0.5)', 5);
			//this.introParatxt.setTextBounds(555, 70, 780, 400);
			this.introParatxt.fontWeight = 'bold';
		}else{
			this.game.add.image(0, 0, 'storyScene');
			// the alignment of the text is independent of the bounds, try changing to 'center' or 'right'
			style = { font: "14px Arial", fill: "#FFF", align: "center", boundsAlignH: "left", boundsAlignV: "top", wordWrap: true, wordWrapWidth: 230 };
			this.introParatxt = this.add.text(0,0, GAMEAPP.introPara, style);
			this.introParatxt.setShadow(3, 3, 'rgba(0,0,0,0.5)', 5);
			this.introParatxt.setTextBounds(550, 138, 780, 400);
			this.introParatxt.fontWeight = 'bold';
		}
		
		//displayCanvas0();
		var Legend = "";
		var format = Math.floor(Math.random()*plotType.length);;  
		var authfig = Math.floor(Math.random()*authorityFigure.length); 
		var destination = Math.floor(Math.random()*greekLetters.length); 
		var transit = Math.floor(Math.random()*greekLetters.length);
		var star = Math.floor(Math.random()*greekLetters.length);	
		var computer = Math.floor(Math.random()*greekNames.length); 
	
	
	console.log("NCC Pandora Rescue");  //debug
	console.log("     "+plotType[format]+" "+authorityFigure[authfig]+" "+greekLetters[destination]+" quadrant. You have secured a government seating on the NCC Pandora ( a scientific research vessel ). Its final destination is the "+greekLetters[transit]+" quadrant; fortunately, it must pass through the "+greekLetters[destination]+" quadrant. \n\n Unknown to you is the NCC Pandora had recently upgraded their navigation system and ship computers on their "+greekNames[destination]+"-"+greekLetters[destination]+"-"+Math.floor(Math.random()*6)+" operating system. Due to a small minut computational error, the NCC Pandora crossed dangerously close to the "+greekLetters[star]+"-"+Math.floor(Math.random()*16)+" star which dirupted all the vessel's computer systems. \n\n You awake from stasis to learn of the ship-wide system shutdown in 30 minutes. Your goal is to find all six ship's computers, manually defrag their memory content sufficiently to survive a full system reboot on each system.");  //debug
		var str = "     "+plotType[format]+" "+authorityFigure[authfig]+" "+greekLetters[destination]+" quadrant. You have secured a government seating on the NCC Pandora ( a scientific research vessel ). Its final destination is the "+greekLetters[transit]+" quadrant; fortunately, it must pass through the "+greekLetters[destination]+" quadrant. \n     Unknown to you is the NCC Pandora had recently upgraded their navigation system and ship computers on their "+greekNames[destination]+"-"+greekLetters[destination]+"-"+Math.floor(Math.random()*6)+" operating system. Due to a small minut computational error, the NCC Pandora crossed dangerously close to the "+greekLetters[star]+"-"+Math.floor(Math.random()*16)+" star which disrupted all the vessel's computer systems. \n     You awake from stasis to learn of the ship-wide system shutdown in 30 minutes. Your goal is to find all six ship's computers, manually defrag their memory content sufficiently to survive a full system reboot on each system. \n";
		 
		
		//Goto main menu
		var buttonContinue = this.game.add.button(this.world.width, this.world.centerY+50, 'button-continue', this.clickContinue, this, 1, 0, 2,0);
		
		buttonContinue.anchor.set(1,1);
		buttonContinue.x = this.world.width+buttonContinue.width+20;
		
		this.add.tween(buttonContinue).to({x: this.world.width-20}, 500, Phaser.Easing.Exponential.Out, true);

		this._toolTip = this.game.add.text(20, this.world.centerY-140, "The Story thus far ... \n"+str, GAMEAPP.styleStory);
		this._toolTip.wordWrap = true;
		this._toolTip.wordWrapWidth =630;
		this._toolTip.anchor.set(0,0);
		this._toolTip.setShadow(3, 3, 'rgba(0,0,0,0.5)', 5);
		this._toolTip.fontWeight = 'bold';
		
		this.camera.flash(0x000000, 500, false);
		
	},
	
	update: function(){
		
	},
	// 
	// =========================================================
	clickContinue: function() {
		//GAMEAPP._playAudio('click');
		this.camera.fade(0x000000, 200, false);
		this.time.events.add(200, function() {
			//BBS & Flash website: TIGStart method
			this.game.state.start('menu');
			//ARRA Main Entrance rv_3 through rv_8
			//this.game.state.start('R6');
		}, this);
		
	},
	// 
	// =========================================================
	// Menu Button function
	// =========================================================
	btnOver: function(butn){
		switch(butn.name){
			case "play":
				console.log("Play selected");
				this._toolTip.setText(GAMEAPP.playtxt); 
			break;
			case "credit":
				console.log("Credit selected");
				this._toolTip.setText(GAMEAPP.credittxt);
			break;
			case "share":
				console.log("Share selected");
				this._toolTip.setText(GAMEAPP.sharetxt);
			break;
			case "options":
				console.log("Options selected");
				this._toolTip.setText(GAMEAPP.opttxt);
			break;
			case "more":
				console.log("More selected");
				this._toolTip.setText(GAMEAPP.moretxt);
			break;
			case "web":
				console.log("Web selected");
				this._toolTip.setText("Webmasters");
			break;
			case "dona":
				console.log("Donations selected");
				this._toolTip.setText("Support us");
			break;
		}
	},
	// 
	// =========================================================
	startGame: function (pointer) {
		//Ok, the Play Button has been clicked or touched, 
		//	so let's stop the music (otherwise it'll carry on playing)
		//this.music.stop();
		//	And start the actual game
		this.state.start('Game');

	},
	GameCredits: function (pointer) {
		//	And start the actual game
		this.state.start('credits');

	},
	GameOptions: function (pointer) {
		//Ok, the Play Button has been clicked or touched, 
		//	so let's stop the music (otherwise it'll carry on playing)
		//this.music.stop();
		//	And start the actual game
		this.state.start('language');

	},
	//uses right-side plugin
	GameShare: function (pointer) {
		//Ok, the Play Button has been clicked or touched, 
		//	so let's stop the music (otherwise it'll carry on playing)
		//this.music.stop();
		//originally moved to separate internal scene; now goes off-site
		window.open("http://www.pbmcube.net/", "_blank");

	},
	
	MoreGame: function (pointer) {
		//Ok, the Play Button has been clicked or touched, 
		//	so let's stop the music (otherwise it'll carry on playing)
		//this.music.stop();
		//	And start the actual game
		//originally moved to separate internal scene; now goes off-site
		window.open("http://www.renown-games.com./index.html", "_blank");

	},
	WebMaster: function (pointer) {
		//Ok, the Play Button has been clicked or touched, 
		//	so let's stop the music (otherwise it'll carry on playing)
		//this.music.stop();
		//	And start the actual game
		//originally moved to separate internal scene; now goes off-site
		window.open("http://shop.pbmcube.net/downloads/category/software-source-code/ssc5/", "_blank");

	},
	
	GameDonations: function (pointer) {
		//Ok, the Play Button has been clicked or touched, 
		//	so let's stop the music (otherwise it'll carry on playing)
		//this.music.stop();
		//	And start the actual game
		//originally moved to separate internal scene; now goes off-site
		window.open("https://www.paypal.me/pbmcube", "_blank");

	},

	
};

/* End of file */
/* Location: ./js/state/story.js */