Phaser Starter Kit Collection&trade; - <GAME MECHANICS NAME> game mechanics  
==========================  
Project Name: Phaser v3.x.x <GAME MECHANICS NAME> Starter Kit  
Description:  
  
 - Project Files for Phaser versions 2.6.2 and community edition.  
 - Phaser 3.x.x found in a separate dedicated chapter.  
  
Website: <http://makingbrowsergames.com/starterkits/<GAME MECHANICS NAME>/>  
Author: Stephen Gose  
Version: 0.0.0.xx  
Phaser Version: 2.6.2 or CE  
Author URL: http://www.stephen-gose.com/  
Support: support@pbmcube.com  
  
Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved.  
  
-------------------------------------------------------------------------  
  
##Do not sell! Do not distribute!  
  
This is a licensed file. Please refer to **Terms of Use and End Users License Agreement (EULA).**  
Search for all the `//TODO comments` to tailor this file for your own use; doing so will void any support agreement.  
  
Redistribution of any part or whole of this file and the accompanying files is strictly prohibited. This is a licensed product.  
  
-------------------------------------------------------------------------  
##Project Content  
  
 - Basic Phaser html temple - matches the instructions found in [Phaser Game Starter kit.](https://leanpub.com/pgskc)  
 - <GAME MECHANICS NAME> Demonstrations - xxx (\#) open source games using alternative coding styles, (and two educational games:)  
  
	1. (my game).  
	2. (my game).  
  
- v2.6.2 - complete <GAME MECHANICS NAME> starter kit using official Phaser release. Simply add your own artwork, sound effects and deploy.  
 - CE version - complete <GAME MECHANICS NAME> starter kit using the most current Community Edition release of Phaser as of (date). It is extremely hard to keep up with the CE releases. Refer to their newest release in the [Phaser newsletter](https://phaser.io/community/newsletter) or [visiting their GitHub](https://github.com/photonstorm/phaser-ce).  Simply add your own artwork and deploy.  
 - Phaser v3.x.x versions are found on the [books website](http://makingbrowsergames.com/starterkits) due to its current dynamic development until its release in 20171101. Once Phaser v3 is launched and stable, new Game Starter Kit books on this game mechanics will follow.  
  
  
-------------------------------------------------------------------------    
  
##Versions  
  
0.0.0.xx - Initial Game.  
  
##Game Demo URL:  
  
 - Phaser Official version 2.6.2: <>  
 - Phaser CE version (20170823): <>  
 - Phaser Official version 3.x.x (201708213): <>  
  
-------------------------------------------------------------------------  
##Technical Description:  
  
This is a simple HTML5 <GAME MECHANICS NAME> Blueprint using the ***Phaser JS Game Framework.*** This project provides a SCRUM Game prototyping for game mechanics and mechanisms found in the [parent book "Phaser Game Prototyping".](https://leanpub.com/LoRD)  
  
The game construction follows the [Game Prototyping using Phaser JavaScript Game Framework Workbook](https://leanpub.com/LoRD) available at Leanpub.com or [Amazon](http://amzn.to/2sEN7y5)  
