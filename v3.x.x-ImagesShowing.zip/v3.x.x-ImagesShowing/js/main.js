/**
 * File Name: Main.js
 * Live Demo: http://www.adventurers-of-renown.com/quests/index-mobile-arbp.html 
 * Source Code: http://makingbrowsergames.com/book/
 * Description: File for controlling and displaying game scenes; 
 * 		managing global variables throughout game state.
 * Author: Stephen Gose
 * Version: 0.0.0.17
 * Phaser Version: 3.x.x
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //TODO ] to tailor this file for your own use; 
 *	 doing so will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 */
"use strict";
/**	game set-up	**/
//Beginning of Static databases
//TODO 
// NOTE: the following data structures are for development only.
//	The optimum usage is a local or remote database using PouchDB or SQLite.
//	Stay away from IndexDB since it is deprecated.
console.log("%c      Starting my awesome MMoG game Prototype!     \n     Phaser Match 3 Game Prototyping Starter Kit   \n        Copyright \u00A9 1974-2017,  Stephen Gose.      \n  | http://shop.pbmcube.net/ |                      \n  | \u2665\u2665\u2665\u2665\u2665 -> $120 License included in book!        \n  | Book available at: http://leanpub.com/LoRD |   ",
	"color:white; background:blue");
var boardGroup;
var selectedTile;
// 
// =========================================================
//TODO Creating Game namespace called GAMEAPP; refactor GAMEAPP with your project name
window.GAMEAPP = {
	//US Copr. or Copyright; UTF8 circled c is \u00A9 equal to &copy;
	Copr: "Copyright © \u00A9 1974-2016, Stephen Gose. All rights reserved.\n",
	// reference to the Phaser.Game instance
	game: null,
	
	// If there's music in your game, and it needs to play through-out a 
	//	  few State swaps, then you could reference it below. 
	//music: null,
	
	//Toggle background music theme on or off; starts in "on/true" state 
	//musicToggle: true,
	
	//Your game can check MYGAMEAPP.orientated in the game loops 
	//	  to know if it should pause or not.
	//orientated: false,
	
		
	/**
	//Grid Tile-Map configurations
	//TODO Remote this static database onto database server; otherwise upgrade to PouchDB or SQLite
	//Tile-maps are the visual express separate from the Movement Tables metadata.
	tileSize: 64,	//twice the size of an avatar icon
	numRows: 3,		//adjustable for your game
	numCols: 3,		//adjustable for your game
	tileSpacing: 2,	//adjustable for your game
	tilesArray: [], //one way; thousand more to choose
	*/
	//Canvas dimensions: world and viewportHeight
	//TODO adjust for your game deployment
	viewportWidth: 640,	//Golden ration game view
	viewportHeight: 400,
	worldWidth: 640,	//Golden ration world view
	worldHeight: 400,
	
	// =========================================================
	//TODO refactor and adjust for your game deployment
	//	Trash Global Variables (alphabetical)
	//	Here we have some global level vars that persist regardless of State. 
	// =========================================================
	fieldSize: 7,
	tileTypes: 5,
	tileSize: 40,
	//
	swapSpeed: 200,
	fallSpeed: 500,
	destroySpeed: 200,
	fastFall: true,
	//
	gameArray: [],
	removeMap: [],
	canPick: true,
	//Scoring
	score3: 0,	//3 in a row matches
	score4: 0,	//4 in a row matches
	score5: 0,	//5 in a row matches
	comboT: false,	//combination toggle sentinel for combinations earned
	comboCntr: 0,
	scoreC: 0,	//Combinations scored
	
	//HUD styling
	styleHUD: { font: "16px Arial", fill: "#ff9900", align: "left" },
	
	// here we will store all game phase/states
	//  state object filled as js files load.
	state: {},
	
	// =========================================================
	// -------------------------------------------
	// Main game Handler methods
	// -------------------------------------------
	//TODO:
	//	refactor and adjust for your game deployment
	//	remove console debug information on public deployment
	// =========================================================
	main: function(){
		/**
		 
		 //v2
		this.game = new Phaser.Game(window.GAMEAPP.viewportWidth, window.GAMEAPP.viewportHeight, Phaser.AUTO, document.body, window.GAMEAPP.state.boot);
		*/
		//Phaser v3.x.x
		this.game = new Phaser.Game({
			type: Phaser.AUTO,
			parent: document.body,
			scene: [],
			width: window.GAMEAPP.viewportWidth,
			height: window.GAMEAPP.viewportHeight
			
		});
		
		// add all game states
			for(var stateName in window.GAMEAPP.state){
				console.log("Crnt State: "+stateName);
				game.scene.add(stateName, window.GAMEAPP.state[stateName]);
			}
		//using v3? use this below.
		this.game.scene.start('boot');
		
	},
	// =========================================================
	// -------------------------------------------
	// Supporting game Function & Classes
	// -------------------------------------------
	//TODO:
	//	Change namespace from generic GAMEAPP to your project 
	//	refactor and adjust for your game deployment
	//	remove console debug information on public deployment
	// =========================================================
}

/** DEPRECATED METHOD - NEVER EVER USE THIS!
* 	See Phaser.js Game Design Workbook for complete explanation
*	http://leanpub.com/phaserjsgamedesignworkbook
* 	window.onload = function () {
*	    let game = new Phaser.Game(0, 0, Phaser.AUTO, document.body);
*	};
*/

//preferred lauch method for BOM.
window.addEventListener('DOMContentLoaded', function(){
	window.GAMEAPP.main();
}, false);

/** End of file
 *  Location: /js/main.js
 */