/**
 * File Name: boot.js
 * Live Demo: http://www.adventurers-of-renown.com/quests/index-mobile-arbp.html 
 * Source Code: http://makingbrowsergames.com/book/
 * Description: File for controlling initial game shell launch; 
 *	 managing global variables throughout game state.
 * Author: Stephen Gose
 * Version: 0.0.0.17
 * Phaser Version: 2.6.2 or CE 2.8.x
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //TODO ] to tailor this file for your own use and will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 */
"use strict";
window.GAMEAPP.state.boot = {
	preload: function(){
		// required assets for following states here
		this.load.image('scoreHUD', 'assets/images/scoreBar.png');
		this.load.spritesheet("tiles", 'assets/spriteSheets/arbp-m3.png', {frameWidth:40, frameHeight: 40, endFrame: 5});
	},
	create: function(){
		// add all game states
		/** moved to main; v3 doesn't seem to work here
			// add all game states
			for(var stateName in window.GAMEAPP.state){
				console.log("Crnt State: "+stateName);
				game.scene.add(stateName, window.GAMEAPP.state[stateName]);
			}
		*/
		
		// goto load state
		this.scene.start("load");
	},
	enableScaling: function(){
		var game = this.game;
		game.scale.parentIsWindow = (game.canvas.parentNode == document.body);
		game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
	}
};
/** End of file
 *  Location: /js/states/boot.js
 */