/*
 * This file is automatically loaded from state/load.js
 * to change default state - change state/load.js at line: 10
 */
"use strict";
window.GAMEAPP.state.demo = {
	create: function(){
				
		// prevent pause on focus lost
		this.game.stage.disableVisibilityChange = true;
	}
};
/** End of file
 *  Location: /js/states/demo.js
 */