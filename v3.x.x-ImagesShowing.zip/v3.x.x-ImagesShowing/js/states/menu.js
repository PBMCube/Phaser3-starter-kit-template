/**
 * File Name: menu.js
 * Live Demo: http://www.adventurers-of-renown.com/quests/index-mobile-arbp.html 
 * Source Code: http://makingbrowsergames.com/book/
 * Description: File for controlling assets downloads; some delegations to browser.
 * Author: Stephen Gose
 * Version: 0.0.0.17
 * Phaser Version: 2.6.2 or CE 2.8.x
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved. 
 * 
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //TODO ] to tailor this file for your own use and will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 */
"use strict";
window.GAMEAPP.state.menu = {
	preload: function(){
		
	},
	
	create: function(){
		
		
	},
	
	update: function(){
		
	}
};
/** End of file
 *  Location: /js/states/menu.js
 */