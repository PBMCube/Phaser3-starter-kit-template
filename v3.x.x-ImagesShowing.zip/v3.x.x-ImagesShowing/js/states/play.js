/**
 * File Name: play.js
 * Live Demo: http://www.adventurers-of-renown.com/quests/index-mobile-arbp.html
 * Source Code: http://makingbrowsergames.com/starterkits/
 * Description: File for controlling game logic;
 * Author: Stephen Gose
 * Version: 0.0.0.17 using Phaser v3.x.x
 * Author URL: http://www.stephen-gose.com/
 * Support: support@pbmcube.com
 *
 * Copyright © \u00A9 1974-2017 Stephen Gose LLC. All rights reserved.
 *
 * Do not sell! Do not distribute!
 * This is a licensed permission file. Please refer to Terms of Use
 *   and End Users License Agreement (EULA).
 * Search for [ //TODO ] to tailor this file for your own use and will void any support agreement.
 *
 * Redistribution of part or whole of this file and
 * the accompanying files is strictly prohibited.
 *
 */

"use strict";
window.GAMEAPP.state.play = {
	preload: function () {
		console.log("loading play state");
		this.load.spritesheet('tiles', 'assets/spriteSheets/arbp-m3.png', { frameWidth: 40, frameHeight: 40 });

	},

	create: function () {
		console.log("starting play state");
		//background theme loaded from boot phase
		var hudBkGrnd = this.add.image( 100, 282, 'scoreHUD');
		hudBkGrnd.setPosition(0,280).setOrigin(0);
		
		
		//HUD
		var txtStyle = {font: "16px Arial", fill: "#ff9900", align: "left"};
		this._score3 = this.make.text(this, 20, 300, GAMEAPP.score3 , txtStyle);
		this._score3.setPosition(160,300);
		this._score4 = this.make.text(this, 20, 320, GAMEAPP.score4 , txtStyle);
		this._score4.setPosition(160,320);
		this._score5 = this.make.text(this, 20, 340, GAMEAPP.score5 , txtStyle);
		this._score5.setPosition(160,340);
		this._scoreC = this.make.text(this, 20, 360, GAMEAPP.scoreC , txtStyle);
		this._scoreC.setPosition(160,360);
		
		//create game board
		drawField();
//==========================================================================	
//Scenario 1:
//unable to position gropu correctly
//==========================================================================
/**
//http://phaser.io/phaser3/api/group
//http://labs.phaser.io/edit.html?src=src\game%20objects\group\random%20frame.js

//  This will create a Group with 400 children.
//  Each child will use the 'bobs' texture and a random frame number between 0 and 399 (inclusive)
//  Change 'randomFrame' to false to see the difference it makes

var group = this.make.group({
	key: 'tiles',
	frame: Phaser.Utils.Array.NumberArray(0, 4),
	randomFrame: true,
	gridAlign: {
		width: 6,
		height: 6,
		cellWidth: 40,
		cellHeight: 40
	}
	
});
*/
/**
//==========================================================================	
//Scenario 2:
//tilemap
//==========================================================================
//http://labs.phaser.io/edit.html?src=src\game%20objects\tilemap\dynamic\endless%20map.js
//former drawField()
	var tileSZ = GAMEAPP.tileSize;
	var gameBoard = GAMEAPP.fieldSize;
	
	var boardGroup = this.make.group();
	for (var i = 0; i < gameBoard; i++) {
		GAMEAPP.gameArray[i] = [];
		for (var j = 0; j < gameBoard; j++) {
			var cell = this.add.sprite(tileSZ * j + tileSZ / 2, tileSZ * i + tileSZ / 2, "tiles");
			cell.setOrigin(0);
			boardGroup.add(cell);
			do {
				//var randomColor = GAMEAPP.game.rnd.between(0, GAMEAPP.tileTypes - 1);
				var randomColor = Math.floor(Math.random() * Math.floor(GAMEAPP.tileTypes - 1));
				console.log("Random Color: "+randomColor);
				cell.frame = randomColor;
				GAMEAPP.gameArray[i][j] = {
					tileColor: randomColor,
					tileFrame: cell
				}
			} while (isMatch(i, j));
		}
		console.table(GAMEAPP.gameArray)
	}
	
	
//==========================================================================	
	selectedTile = null;
	
		GAMEAPP.canPick = true;
		//GAMEAPP.game.input.onDown.add(tileSelect);
		//GAMEAPP.game.input.onUp.add(tileDeselect);
	*/	
	},

	update: function () {
		
		
	}
};

function drawField() {
//==========================================================================
//original v2 works
//==========================================================================

//v3 Scenario 2 - using Tilemap
//http://phaser.io/phaser3/api/tilemap
//var GAMEAPP.gameArray = [];
var tileSZ = GAMEAPP.tileSize;
var gameBoard = GAMEAPP.fieldSize;

var mapConfig = {
    map: {
        data: GAMEAPP.gameArray,
        width: GAMEAPP.viewportWidth,
        height: GAMEAPP.viewportHeight,
    },
    tile: {
        width: 40,
        height: 40,
        texture: 'tiles'
    }
};
console.log(mapConfig);
//GAMEAPP.gameArray = this.make.tilemap(mapConfig);

for (var y = 0; y < gameBoard; y++)
{
    for (var x = 0; x < gameBoard; x++)
    {
        //  Scatter the tiles so we get more mud and less stones
        GAMEAPP.gameArray.push(Phaser.Math.RND.weightedPick(tile));
    }
}

//==========================================================================
	selectedTile = null;
}

function tileSelect(e) {
	//console.log("entered tile select");
	var tileSZ = GAMEAPP.tileSize;
	//console.log ("Recorded size: "+ tileSZ);
	if (GAMEAPP.canPick) {
		var row = Math.floor(GAMEAPP.game.input.activePointer.y / tileSZ);
		//console.log("ModuloY: "+ Math.floor(GAMEAPP.game.input.activePointer.y / tileSZ));
		//console.log('X:' + GAMEAPP.game.input.activePointer.x);
		var col = Math.floor(GAMEAPP.game.input.activePointer.x / tileSZ);
		//console.log('Y:' + GAMEAPP.game.input.activePointer.y);
		console.log("Row: "+row+"; Column: "+col);
		var pickedTile = gemAt(row, col);
		
		if (pickedTile != -1) {
			if (selectedTile == null) {
				pickedTile.tileFrame.scale.setTo(1.2);
				pickedTile.tileFrame.bringToTop();
				selectedTile = pickedTile;
				GAMEAPP.game.input.addMoveCallback(orbMove);
			} else {
				if (areTheSame(pickedTile, selectedTile)) {
					selectedTile.tileFrame.scale.setTo(1);
					selectedTile = null;
				} else {
					if (areNext(pickedTile, selectedTile)) {
						selectedTile.tileFrame.scale.setTo(1);
						swapOrbs(selectedTile, pickedTile, true);
					} else {
						selectedTile.tileFrame.scale.setTo(1);
						pickedTile.tileFrame.scale.setTo(1.2);
						selectedTile = pickedTile;
						GAMEAPP.game.input.addMoveCallback(orbMove);
					}
				}
			}
		}
	}
	//debug
	//console.table(GAMEAPP.gameArray);
}

function tileDeselect(e) {
	GAMEAPP.game.input.deleteMoveCallback(orbMove);
		GAMEAPP.state.play._scoreC.setText("Combinations!: "+GAMEAPP.scoreC);
		GAMEAPP.state.play._score5.setText("   Matches x5: "+GAMEAPP.score5);
		GAMEAPP.state.play._score4.setText("   Matches x4: "+ GAMEAPP.score4);
		GAMEAPP.state.play._score3.setText("      Matches: "+ GAMEAPP.score3);
}

function orbMove(event, pX, pY) {
	if (event.id == 0) {
		var distX = pX - selectedTile.tileFrame.x;
		var distY = pY - selectedTile.tileFrame.y;
		var deltaRow = 0;
		var deltaCol = 0;
		if (Math.abs(distX) > GAMEAPP.tileSize / 2) {
			if (distX > 0) {
				deltaCol = 1;
			} else {
				deltaCol = -1;
			}
		} else {
			if (Math.abs(distY) > GAMEAPP.tileSize / 2) {
				if (distY > 0) {
					deltaRow = 1;
				} else {
					deltaRow = -1;
				}
			}
		}
		if (deltaRow + deltaCol != 0) {
			var pickedTile = gemAt(getOrbRow(selectedTile) + deltaRow, getOrbCol(selectedTile) + deltaCol);
			if (pickedTile != -1) {
				selectedTile.tileFrame.scale.setTo(1);
				swapOrbs(selectedTile, pickedTile, true);
				GAMEAPP.game.input.deleteMoveCallback(orbMove);
			}
		}
	}
}

function swapOrbs(orb1, orb2, swapBack) {
	//here's where we set the combo sentinel
	GAMEAPP.combo = 0;
	GAMEAPP.canPick = false;
	var fromColor = orb1.tileColor;
	var fromSprite = orb1.tileFrame;
	var toColor = orb2.tileColor;
	var toSprite = orb2.tileFrame;
	GAMEAPP.gameArray[getOrbRow(orb1)][getOrbCol(orb1)].tileColor = toColor;
	GAMEAPP.gameArray[getOrbRow(orb1)][getOrbCol(orb1)].tileFrame = toSprite;
	GAMEAPP.gameArray[getOrbRow(orb2)][getOrbCol(orb2)].tileColor = fromColor;
	GAMEAPP.gameArray[getOrbRow(orb2)][getOrbCol(orb2)].tileFrame = fromSprite;
	var orb1Tween = GAMEAPP.game.add.tween(GAMEAPP.gameArray[getOrbRow(orb1)][getOrbCol(orb1)].tileFrame).to({
			x: getOrbCol(orb1) * GAMEAPP.tileSize + GAMEAPP.tileSize / 2,
			y: getOrbRow(orb1) * GAMEAPP.tileSize + GAMEAPP.tileSize / 2
		}, GAMEAPP.swapSpeed, Phaser.Easing.Linear.None, true);
	var orb2Tween = GAMEAPP.game.add.tween(GAMEAPP.gameArray[getOrbRow(orb2)][getOrbCol(orb2)].tileFrame).to({
			x: getOrbCol(orb2) * GAMEAPP.tileSize + GAMEAPP.tileSize / 2,
			y: getOrbRow(orb2) * GAMEAPP.tileSize + GAMEAPP.tileSize / 2
		}, GAMEAPP.swapSpeed, Phaser.Easing.Linear.None, true);
	orb2Tween.onComplete.add(function () {
		if (!matchInBoard() && swapBack) {
			swapOrbs(orb1, orb2, false);
		} else {
			if (matchInBoard()) {
				//reset combination listeners
				GAMEAPP.comboT = false;
				GAMEAPP.comboCntr = 0;
				handleMatches();
			} else {
				GAMEAPP.canPick = true;
				selectedTile = null;
			}
		}
	});
}

function areNext(cell1, cell2) {
	return Math.abs(getOrbRow(cell1) - getOrbRow(cell2)) + Math.abs(getOrbCol(cell1) - getOrbCol(cell2)) == 1;
}

function areTheSame(cell1, cell2) {
	return getOrbRow(cell1) == getOrbRow(cell2) && getOrbCol(cell1) == getOrbCol(cell2);
}

function gemAt(row, col) {
	var gameBoard = GAMEAPP.fieldSize;
	if (row < 0 || row >= gameBoard || col < 0 || col >= gameBoard) {
		return -1;
	}
	return GAMEAPP.gameArray[row][col];
}

function getOrbRow(cell) {
	var tileSZ = GAMEAPP.tileSize;
	return Math.floor(cell.tileFrame.y / tileSZ);
}

function getOrbCol(cell) {
	var tileSZ = GAMEAPP.tileSize;
	return Math.floor(cell.tileFrame.x / tileSZ);
}

function isHorizontalMatch(row, col) {
	return gemAt(row, col).tileColor == gemAt(row, col - 1).tileColor && gemAt(row, col).tileColor == gemAt(row, col - 2).tileColor;
}

function isVerticalMatch(row, col) {
	return gemAt(row, col).tileColor == gemAt(row - 1, col).tileColor && gemAt(row, col).tileColor == gemAt(row - 2, col).tileColor;
}

function isMatch(row, col) {
	return isHorizontalMatch(row, col) || isVerticalMatch(row, col);
}

function matchInBoard() {
	var gameBoard = GAMEAPP.fieldSize;
	for (var i = 0; i < gameBoard; i++) {
		for (var j = 0; j < gameBoard; j++) {
			if (isMatch(i, j)) {
				return true;
			}
		}
	}
	return false;
}

function handleMatches() {
	GAMEAPP.removeMap = [];
	var gameBoard = GAMEAPP.fieldSize;
	
	for (var i = 0; i < gameBoard; i++) {
		GAMEAPP.removeMap[i] = [];
		for (var j = 0; j < gameBoard; j++) {
			GAMEAPP.removeMap[i].push(0);
		}
	}
	//console.log("ln 218: handling matches");
	
	handleHorizontalMatches();
	handleVerticalMatches();
	destroyOrbs();
	if(GAMEAPP.comboT == true){GAMEAPP.comboCntr +=1;}
	if(GAMEAPP.comboCntr >1){
		GAMEAPP.scoreC += GAMEAPP.comboCntr; 
		console.log("Combinations: "+GAMEAPP.comboCntr);
		console.log("match combination scored: "+GAMEAPP.scoreC);
	}
}

function handleVerticalMatches() {
	GAMEAPP.comboT = true;	//turn on sentinel to count combinations achieved.
	var gameBoard = GAMEAPP.fieldSize;
	
	for (var i = 0; i < gameBoard; i++) {
		var colorStreak = 1;
		var currentColor = -1;
		var startStreak = 0;
		for (var j = 0; j < gameBoard; j++) {
			if (gemAt(j, i).tileColor == currentColor) {
				colorStreak++;
			}
			if (gemAt(j, i).tileColor != currentColor || j == gameBoard - 1) {
				if (colorStreak >= 3) {
					console.log("VERTICAL :: Length = " + colorStreak + " :: Start = (" + startStreak + "," + i + ") :: Color = " + currentColor);
					
					for (var k = 0; k < colorStreak; k++) {
						GAMEAPP.removeMap[startStreak + k][i]++;
					}
				}
				//Scoring preserved
				switch (colorStreak){
					case 3:GAMEAPP.score3 += 1;
						console.log("match 3 scored: "+GAMEAPP.score3);
					break;
					case 4:GAMEAPP.score4 += 1;
						console.log("match 4 scored: "+GAMEAPP.score4);
					break;
					case 5:GAMEAPP.score5 += 1;
						console.log("match 5 scored: "+GAMEAPP.score5);
					break;
					
				}
				
				startStreak = j;
				colorStreak = 1;
				currentColor = gemAt(j, i).tileColor;
			}
		}
	}
}

function handleHorizontalMatches() {
	GAMEAPP.comboT = true;	//turn on sentinel to count combinations achieved.
	var gameBoard = GAMEAPP.fieldSize;
	
	for (var i = 0; i < gameBoard; i++) {
		var colorStreak = 1;
		var currentColor = -1;
		var startStreak = 0;
		for (var j = 0; j < gameBoard; j++) {
			if (gemAt(i, j).tileColor == currentColor) {
				colorStreak++;
			}
			if (gemAt(i, j).tileColor != currentColor || j == gameBoard - 1) {
				if (colorStreak >= 3) {
					console.log("HORIZONTAL :: Length = " + colorStreak + " :: Start = (" + i + "," + startStreak + ") :: Color = " + currentColor);
					
					for (var k = 0; k < colorStreak; k++) {
						GAMEAPP.removeMap[i][startStreak + k]++;
					}
				}
				//Scoring preserved
				switch (colorStreak){
					case 3:GAMEAPP.score3 += 1;
						console.log("match 3 scored: "+GAMEAPP.score3);
					break;
					case 4:GAMEAPP.score4 += 1;
						console.log("match 4 scored: "+GAMEAPP.score4);
					break;
					case 5:GAMEAPP.score5 += 1;
						console.log("match 5 scored: "+GAMEAPP.score5);
					break;
					
				}
				
				startStreak = j;
				colorStreak = 1;
				currentColor = gemAt(i, j).tileColor;
			}
		}
	}
}

function destroyOrbs() {
	var destroyed = 0;
	var gameBoard = GAMEAPP.fieldSize;
	
	for (var i = 0; i < gameBoard; i++) {
		for (var j = 0; j < gameBoard; j++) {
			if (GAMEAPP.removeMap[i][j] > 0) {
				var destroyTween = GAMEAPP.game.add.tween(GAMEAPP.gameArray[i][j].tileFrame).to({
						alpha: 0
					}, GAMEAPP.destroySpeed, Phaser.Easing.Linear.None, true);
				destroyed++;
				destroyTween.onComplete.add(function (orb) {
					orb.destroy();
					destroyed--;
					if (destroyed == 0) {
						makeOrbsFall();
						if (GAMEAPP.fastFall) {
							replenishField();
						}
					}
				});
				GAMEAPP.gameArray[i][j] = null;
			}
		}
	}
}

function makeOrbsFall() {
	var fallen = 0;
	var restart = false;
	var gameBoard = GAMEAPP.fieldSize;
	var tileSZ = GAMEAPP.tileSize;
	
	for (var i = gameBoard - 2; i >= 0; i--) {
		for (var j = 0; j < gameBoard; j++) {
			if (GAMEAPP.gameArray[i][j] != null) {
				var fallTiles = holesBelow(i, j);
				if (fallTiles > 0) {
					if (!GAMEAPP.fastFall && fallTiles > 1) {
						fallTiles = 1;
						restart = true;
					}
					var orb2Tween = GAMEAPP.game.add.tween(GAMEAPP.gameArray[i][j].tileFrame).to({
							y: GAMEAPP.gameArray[i][j].tileFrame.y + fallTiles * tileSZ
						}, GAMEAPP.fallSpeed, Phaser.Easing.Linear.None, true);
					fallen++;
					orb2Tween.onComplete.add(function () {
						fallen--;
						if (fallen == 0) {
							if (restart) {
								makeOrbsFall();
							} else {
								if (!GAMEAPP.fastFall) {
									replenishField();
								}
							}
						}
					})
					GAMEAPP.gameArray[i + fallTiles][j] = {
						tileFrame: GAMEAPP.gameArray[i][j].tileFrame,
						tileColor: GAMEAPP.gameArray[i][j].tileColor
					}
					GAMEAPP.gameArray[i][j] = null;
				}
			}
		}
	}
	if (fallen == 0) {
		replenishField();
	}
}

function replenishField() {
	var replenished = 0;
	var restart = false;
	var gameBoard = GAMEAPP.fieldSize;
	var tileSZ = GAMEAPP.tileSize;
	
	for (var j = 0; j < gameBoard; j++) {
		var emptySpots = holesInCol(j);
		if (emptySpots > 0) {
			if (!GAMEAPP.fastFall && emptySpots > 1) {
				emptySpots = 1;
				restart = true;
			}
			for (var i = 0; i < emptySpots; i++) {
				var orb = GAMEAPP.game.add.sprite(tileSZ * j + tileSZ / 2,  - (tileSZ * (emptySpots - 1 - i) + tileSZ / 2), "tiles");
				orb.anchor.set(0.5);
				boardGroup.add(orb);
				var randomColor = GAMEAPP.game.rnd.between(0, GAMEAPP.tileTypes - 1);
				orb.frame = randomColor;
				GAMEAPP.gameArray[i][j] = {
					tileColor: randomColor,
					tileFrame: orb
				}
				var orb2Tween = GAMEAPP.game.add.tween(GAMEAPP.gameArray[i][j].tileFrame).to({
						y: tileSZ * i + tileSZ / 2
					}, GAMEAPP.fallSpeed, Phaser.Easing.Linear.None, true);
				replenished++;
				orb2Tween.onComplete.add(function () {
					replenished--;
					if (replenished == 0) {
						if (restart) {
							makeOrbsFall();
						} else {
							if (matchInBoard()) {
								GAMEAPP.game.time.events.add(250, handleMatches);
							} else {
								GAMEAPP.canPick = true;
								selectedTile = null;
							}
						}
					}
				})
			}
		}
	}
}

function holesBelow(row, col) {
	var result = 0;
	var gameBoard = GAMEAPP.fieldSize;
	
	for (var i = row + 1; i < gameBoard; i++) {
		if (GAMEAPP.gameArray[i][col] == null) {
			result++;
		}
	}
	return result;
}

function holesInCol(col) {
	var result = 0;
	var gameBoard = GAMEAPP.fieldSize;
	
	for (var i = 0; i < gameBoard; i++) {
		if (GAMEAPP.gameArray[i][col] == null) {
			result++;
		}
	}
	return result;
}
/** End of file
 *  Location: /js/states/play.js
 */