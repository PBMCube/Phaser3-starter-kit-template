//Phaser3 template modified from brunch phaser
// See <https://github.com/photonstorm/phaser/blob/master/src/boot/Config.js>
	var GAMEAPP = new Phaser.Game(
	{

		width: 800,	//maintain Golden Ration
		height: 500,//maintain Golden Ration
		// zoom: 1,
		// resolution: 1,
		//type options:  Phaser.CANVAS, Phaser.WEBGL, or Phaser.AUTO 
		//   which automatically tries to use WebGL, but if the browser 
		//   or device doesn't support it it'll fall back to Canvas.
		type: Phaser.AUTO,
		// parent: null,
		// canvas: null,
		// canvasStyle: null,
		// seed: null,
		//Open the Dev Tools  
		//The title of your game will appear in the banner text  
		title: 'Phaser3 Game Prototyping Starter Kit',		//Game Title
		//url: 'http://makingbrowsergames.com/starterkits/',	//Game URL location
		//The version of your game appears after the title in the banner
		version: '0.0.1.0 semver ',	//http://semver.org/spec/v1.0.0.html
		input: {
			keyboard: true,
			mouse: true,
			touch: true,
			gamepad: false
		},
		// disableContextMenu: false,
		// banner: false
		//The colors at the start of the background array define the blocks  
		//  at the beginning of the banner  
		banner: {
			//to hide these config in the Developer console  
			hidePhaser: false,	 //true conceals; false make visiable
			text: 'white',
			background: ['#e54661', '#ffa644', '#998a2f', '#2c594f', '#002d40']
		},
		//Frame Rate config
		//fps: {
		//	min: 10,
		//	target: 60,
		//	forceSetTimeout: false,
		//	deltaHistory: 10
		//},
		
		// pixelArt: false,
		// autoResize: false,
		// roundPixels: false,
		// transparent: false,
		// clearBeforeRender: true,
		// backgroundColor: 0x000000,	// black
		
		//  Callbacks
		// callbacks:	{
				//preBoot: NOOP,
				//postBoot: NOOP,
		//},
		
		//Physics
		//  physics: {
		//      system: 'impact',
		//      setBounds: true,
		//      gravity: 0,
		//      cellSize: 64
		//  },
		
		//  Loader Config Defaults
		loader: {
			//baseURL: '',				//site lock for game assets
			path: 'assets/',
			maxParallelDownloads: 10,	//varies by browser from 2 to 60
			crossOrigin: 'anonymous',	//required for affiliate usage
			asyn: true,
			//password: ''
			//timeout: 0
		},
		
	  scene: [
		//'boot':'scenes/boot',
		//require('scenes/default'),
		//require('scenes/menu')
	  ],

	}
	);

	
	this.scene.add('boot', window.GAMEAPP.boot);
	this.scene.add('default', window.GAMEAPP.default);
	this.scene.add('menu', window.GAMEAPP.menu);

this.scene.start('boot');
