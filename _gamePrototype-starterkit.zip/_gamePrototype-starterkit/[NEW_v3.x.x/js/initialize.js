//window.game = new Phaser.Game({

//New Phaser3 template modified from brunch phaser
//	name change from initialize.js -> main.js
window.GAMEAPP = new Phaser.Game({

	// See <https://github.com/photonstorm/phaser/blob/master/src/boot/Config.js>

	width: 800,			//maintain Golden Ration
	height: 500,		//maintain Golden Ration
	// zoom: 1,
	// resolution: 1,
	type: Phaser.AUTO,
	// parent: null,
	// canvas: null,
	// canvasStyle: null,
	// seed: null,
	title: 'Phaser3 Game Prototyping Starter Kit',		//Game Title
	url: 'http://makingbrowsergames.com/starterkits/',	//Game URL location
	version: 'semver 0.0.1.0',	//http://semver.org/spec/v1.0.0.html
	input: {
		keyboard: true,
		mouse: true,
		touch: true,
		gamepad: false
	},
	// disableContextMenu: false,
	// banner: false
	banner: {
		hidePhaser: false,
		text: 'white',
		background: ['#e54661', '#ffa644', '#998a2f', '#2c594f', '#002d40']
	},
	//Frame Rate config
	//fps: {
	//	min: 10,
	//	target: 60,
	//	forceSetTimeout: false,
	//	deltaHistory: 10
	//},
	
	// pixelArt: false,
	// transparent: false,
	// clearBeforeRender: true,
	// backgroundColor: 0x000000,	// black
	
	//  Callbacks
	// callbacks:	{
			//preBoot: NOOP,
			//postBoot: NOOP,
	//},
	
	//Physics
	//  physics: {
	//      system: 'impact',
	//      setBounds: true,
	//      gravity: 0,
	//      cellSize: 64
	//  },
	
	//  Loader Defaults
	loader: {
		//baseURL: '',				//site lock for game assets
		path: 'assets/',
		maxParallelDownloads: 10,	//varies by browser from 2 to 60
		crossOrigin: 'anonymous',	//required for affiliate usage
		asyn: true,
		//password: ''
		//timeout: 0
	},
	
  scene: [
    require('scenes/boot'),
    require('scenes/default'),
    require('scenes/menu')
  ],

});
